<div class="copyright">
        <p>
            © Copyright 2023 by Adeez. All Rights
            Reserved.
        </p>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<?php /**PATH D:\PKL\Tugas\Web\SPV4\resources\views/layouts/footer.blade.php ENDPATH**/ ?>