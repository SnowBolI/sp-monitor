<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar_inner">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand">
                        <img src="<?php echo e(asset('logobank.png')); ?>" alt="Logo" style="height: 60px; margin-left: 5px; margin-right: 8px;">    
                        Monitoring SP
                    </a>
                    <ul class="d-flex justify-content-end w-100">
                    <?php if(auth()->guard()->check()): ?>
                    <div class="user-menu">Welcome <?php echo e(Auth::user()->name); ?></div>
                    <div class="menu-container">
                        <button id="menuButton" class="menu-button">
                            <i class="fas fa-bars"></i> Menu
                        </button>
                        <div id="menuDropdown" class="menu-dropdown">
                            <?php if(Auth::user()->jabatan_id == 99): ?> 
                            <a href="<?php echo e(route('super-admin.cabang')); ?>" class="menu-item">
                                <i class="fas fa-code-branch"></i> Cabang
                            </a>
                            <a href="<?php echo e(route('super-admin.kantorkas')); ?>" class="menu-item">
                                <i class="fa fa-area-chart"></i> Kantor Kas
                            </a>
                            <a href="<?php echo e(route('super-admin.key')); ?>" class="menu-item">
                                <i class="fas fa-key"></i> Key
                            </a>
                            <a href="<?php echo e(route('super-admin.dashboard')); ?>" class="menu-item">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                            <?php endif; ?> 
                            <a href="<?php echo e(route('logout')); ?>" class="menu-item">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                            <a href="<?php echo e(route('password.change.form')); ?>" class="menu-item">
                                <i class="fas fa-key"></i> Change Password
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                    <li><a class="custom-btn" href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li><a class="custom-btn" href="<?php echo e(route('register')); ?>">Registration</a></li>
                    <?php endif; ?>
                </ul>
                    </nav>
                    <div class="navbar-underline"></div>
                </div>
            </div>
        </div>
        <?php echo $__env->yieldContent('main-content'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH D:\PKL\Tugas\Web\SPV4\resources\views/layouts/master.blade.php ENDPATH**/ ?>